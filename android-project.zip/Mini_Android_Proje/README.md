# Mini — Android WebView test uygulaması

Android 16 telefonda test edilmek üzere hazırlanmış basit, tek sekmeli HTTPS tarayıcı.

## Derleme
Android Studio ile projeyi açın, Gradle senkronizasyonu tamamlandıktan sonra
Build > Build APK(s) seçin. APK app/build/outputs/apk/debug/ altında oluşur.

## Sınır
Bu proje **telefon uygulamasıdır**. Android Auto araç ekranında görüntülenmesi
için resmî bir tarayıcı uygulama kategorisi bulunmaz. Android Auto uyumluluğu
iddia edilmez. Uygulama başka bir kategori gibi tanıtılmaz.
