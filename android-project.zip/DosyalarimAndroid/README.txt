Android Studio ile klasörü açın. Gradle senkronizasyonunu tamamlayın.
Build > Build Bundle(s) / APK(s) > Build APK(s) ile APK üretin.
APK yolu: app/build/outputs/apk/debug/app-debug.apk
Not: Bu ortamda Android SDK ve Gradle bulunmadığından APK derlenemedi.
