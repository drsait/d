# ProGuard kurallari
-keepattributes *Annotation*
