# Mini — Android Auto için deneysel HTTPS tarayıcı

**Sürüm 1.0.0 — kaynak kod.** Mevcut Mini'nin basit adres çubuğu, geri, ileri, yenile ve ana sayfa kontrolleri korunmuştur. Araç ekranını kullanmayı doğrulayan kullanıcı için açılışta park onayı istenir. Bu kontrol aracın park ettiğini teknik olarak doğrulamaz.

## AA Browser kaynağından ne kullanıldı?

Gönderilen `AABrowser-main.zip` incelendi. Android Auto'da görünmek için kullanılan `AndroidManifest.xml` içindeki CAR_LAUNCHER/NAVIGATION/APP_MAPS kategorileri, `appCategory=game`, `com.google.android.gms.car.application` açıklaması ve `res/xml/automotive_app_desc.xml` kaydı Mini'ye uyarlanmıştır. Tam AA Browser arayüzü, analiz ve reklam/tanıtım kodları **kopyalanmadı**. Bu Android Auto kategorileri tarayıcıların resmî uygulama kategorisi değildir; **uygulama Google onaylı değildir** ve başka sistemlerde görünmeyebilir. Original AABrowser: https://github.com/kododake/AABrowser — GNU GPL-3.0. Bu uyarlamanın kaynak kodu da GPL-3.0 olarak sunulur ve LICENSE dosyası ektedir.

## Özellikler

- Adres çubuğu, HTTPS, arama, geri, ileri, yenile, ana sayfa.
- JavaScript ve DOM storage açık, şüpheli SSL sertifikaları reddedilir.
- İlk girişte yalnızca park hâli için uyarı ve kullanıcı onayı.
- Ağ dışında servis, reklam veya telemetri içermez.
- Telefon ile Android Auto araç ekranında deneysel kullanım; AA Browser gibi görünmesi garanti değildir.

## Derleme

- Android Gradle Plugin 8.9.2; Gradle Wrapper 8.11.1; JDK 17; compile/target SDK 35; min SDK 35 (Android 15+).
- Standart GitHub Actions: `.github/workflows/mini-android-auto.yml`.
- Bilgisayarda: `./gradlew :app:assembleDebug`.
- Kullanıcının HTML APK oluşturucusunda doğrudan bu ZIP'i seç; o oluşturucu kendi Android iş akışını yüklüyor ve içeride `settings.gradle` konumunu otomatik buluyor.
- Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Kurulum ve test

1. Telefonda eski Mini uygulaması varsa kalabilir: yeni paket kimliği `com.mini.auto`.
2. GitHub ile APK oluştur ve telefona kur.
3. Telefon Android Auto geliştirici ayarlarında bilinmeyen kaynaklar zaten açık olmalı (AA Browser'ın çalıştığı düzen).
4. Android Auto bağlantısını kesip yeniden aç; Mini uygulamasını ara.
5. Önce park hâlinde test et; uygulama listede yoksa doğrudan manifest kontrollerini ve APK/AA sürümlerini incele.

**Önemli:** Derleme burada çalıştırılmadı; GitHub Actions veya Android Studio ile doğrulanması gerekiyor. Aracın hareketli olup olmadığı güvenilir biçimde algılanamaz; sürüş sırasında kullanma.
