# Winamp 2.95 — Android Auto / Kullanıcı Betiği Yöneticisi

Bu proje, kullanıcının Android Auto'da çalıştığını doğruladığı **Mini** uygulaması temel alınarak genişletildi. Android Auto görünürlüğü resmî tarayıcı desteği değildir, farklı cihazlarda garanti edilmez. **Yalnızca park hâlinde kullanın.** Açılış onayı aracın gerçek hızını doğrulamaz.

## İstenen özellikler

- Uygulama adı: **Winamp 2.95**; paket kimliği korunmuştur: `com.mini.auto`. Önceden kurulan Mini'nin yerini alabilmesi için sürüm kodu artırılmıştır. Android, imza farklıysa eski uygulamanın kaldırılmasını isteyebilir; kaldırma kayıtlı betikleri de siler.
- Uygulama simgesi: **kullanıcının gönderdiği orijinal Winamp yıldırım ve eşkenar dörtgen çerçeve**. Ekran görüntüsündeki gri zemin ve alttaki yazı çıkarılmıştır; PNG alfa kanalı saydamdır. Üretilen alternatif kulaklıklı tasarım kullanılmamıştır.
- Ana sayfa: `https://music.youtube.com/`.
- Dahili kod: **Winamp - YouTube Music 2.95.37**; yüklenen `.txt` ile bire bir aynı, 1.5 MB boyutundaki kullanıcı betiği.
- `⌘ Kodlar` menüsü: yeni JavaScript yazma; `.js` ve `.txt` dosyası içe alma; kodu düzenleme, dosyadan güncelleme, etkinleştirme/devre dışı bırakma, silme, varsayılan Winamp betiğini geri yükleme ve JavaScript hata günlüğünü kopyalama.
- `// @match` ve `// @include` eşleşmeleri ile uygun **HTTPS** sayfalarında çalıştırılır. `@exclude` ve `@exclude-match` de desteklenir.
- Betik dosyaları uygulama içinde özel yerel depolamada saklanır. Sayfayı yeniledikten sonra yapılan betik değişiklikleri uygulanır.
- Büyük Winamp kodu Android WebView `evaluateJavascript` aktarım sınırlarını aşmamak için **20 KB parçalara** bölünüp sayfa içinde birleştirilerek çalıştırılır.

## Derleme

JDK 17, Gradle 8.11.1, Android Gradle Plugin 8.9.2, compile/target SDK 35, min SDK 35.

```bash
./gradlew :app:assembleDebug
```

Oluşan dosya: `app/build/outputs/apk/debug/app-debug.apk`. Android projesi bir ZIP olarak kullanıcının HTML GitHub APK oluşturucusuna verilebilir. APK burada derlenip cihaz üzerinde test **edilmedi**.

## Teknik sınırlamalar

- Bu bir Tampermonkey klonu değil: `@grant none` biçimindeki sayfa içi JavaScript desteğidir. `GM_*`, otomatik uzak güncelleme, `@require`, `@resource` gibi Tampermonkey API'leri desteklenmez.
- YouTube Music, Android WebView sürümü, oturum açma politikası, DRM veya ses yakalama kısıtları nedeniyle betiğin tüm Winamp/MilkDrop özelliklerinin çalışması garanti değildir.
- Eski uygulama kaldırılırsa özel depolamadaki betik değişiklikleri kaybolur. Kaynakları koruyun.
- Geliştirme tabanı AABrowser yapılandırmasından uyarlanmıştır; GPL-3.0 lisansı/LICENSE ektedir. Resmî araç içi tarayıcı uygulaması değildir.

## 2.95.2 derleme düzeltmesi

GitHub run 45756738768 üzerindeki `ScriptRepository.java:111` derleme hatası giderildi: `JSONArray.put(index, value)` tarafından bildirilen `JSONException`, `IOException` içine alınarak yakalanıyor. Kod yöneticisi/Winamp betiği/simge değiştirilmedi. Derleme doğrulaması GitHub üzerinde henüz tamamlanmadı.

## 2.95.3 menü ve betik çalıştırma düzeltmesi

- Android `AlertDialog` penceresinde `setMessage` ile `setItems` birlikte kullanıldığında, seçim satırlarının görünmemesine yol açan iki menü hatası düzeltildi. Artık **⌘ Kodlar → Dosyadan kod yükle** ve kayıtlı kodu düzenle/etkinleştir/sil işlemleri görünür.
- Winamp dahil tüm etkin betikler eşleşen HTTPS sayfalara ardışık küçük parçalar hâlinde gönderilir. Her parçanın WebView tarafından alındığı doğrulanır. Sonuç ve hatalar ekranın altındaki durum satırına ve **Kodlar → Çalıştırma durumu / JavaScript hata günlüğü** bölümüne yazılır.
- Ana sayfa `https://music.youtube.com/` ve kullanıcının orijinal saydam Winamp simgesi korunmuştur.
- Bu sürüm cihazda veya gerçek GitHub derlemesinde henüz doğrulanmadı; sonuç için yeni rapor gerekir. YouTube Music CSP / WebView kısıtları varsa yeni hata günlüğü sorunun kaynağını gösterebilir.
