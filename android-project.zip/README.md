# Winamp 2.95.5 — Android Auto medya + parkta WebView, tek APK

**Tek Android APK:** `com.mini.auto`. Önceki Winamp 2.95.4 kaynak paketi temel alındı.

## Sürüş ekranı (gerçek medya uygulaması)

`AutoMediaService.java` AndroidX Media3 `MediaLibraryService` + `MediaLibrarySession` + `ExoPlayer` içerir. Android Auto **standart medya arayüzü** üzerinden telefondaki **yerel müzik dosyalarını** listeler/oynatır. Oynat/duraklat/önceki/sonraki işler; medya oturumu ile ilerleme bilgisi ve müzik bildirimi de yönetilir. Telefon ayarlarında Winamp'a **Müzik ve ses** izni verilmelidir. İlk açılışta **“Yerel Müzik Listesi / Sürüş Modu”** düğmesi izni ister ve telefondaki ilk 100 parçayı oynatmak için listeler. Aynı medya servisi Android Auto üzerinde de görünür. Telefonunuzda indekslenmiş yerel şarkı yoksa Android Auto listesi boş görünür. Android Auto'da Android Auto uygulama başlatıcısını yenilemeyi deneyin.

## Park ekranı

Orijinal `MainActivity` ve `ScriptRepository` korunur: `https://music.youtube.com/`, Winamp 2.95.37 JavaScript betiği, kod ekleme/silme/düzenleme/etkinleştirme. Simge değiştirilmedi. Arayüz yalnızca **park hâlinde** kullanılmalıdır. Bu APK gerçek park konumunu doğrulayamaz; navigasyon/video/kod düzenleme ekranını hareket hâlinde açmak amacıyla güvenlik kilidi aşılmaz. Parkta Android Auto'nun WebView penceresini gösterebilmesi aracın host uygulamasına ve izinlerine bağlıdır.

## Önemli sınır

Sürüş modunun ses kaynağı **YouTube Music değil, telefondaki müzik dosyalarıdır**. YouTube Music'in WebView içeriği bu medya oturumuna bağlanmamıştır. Dolayısıyla bu APK, YouTube Music parçalarını sürüşte doğrudan bu uygulamanın Android Auto çalma listesiyle oynatamaz. YouTube Music dinlemek için Android Auto'daki resmî YouTube Music uygulamasını kullanabilirsiniz. Bu ayrım gizlenmemelidir.

## Derleme

ZIP'i mevcut GitHub APK Oluşturucu HTML aracına seçin. `settings.gradle` ve `app` ZIP kökünde. `gradlew` ve GitHub Actions iş akışı dahildir.

Yerli dosyalar MediaStore ile alınır (`READ_MEDIA_AUDIO`). İzin yalnızca telefondan istenir. SDK 35 / Java 17 / AGP 8.9.2 / Media3 1.6.1. Uygulama test cihazında ve gerçek Android Auto'da **henüz derlenip denenmedi**; çalışma garantisi verilmez.

## Kaynak ve lisans

Winamp userscripti kullanıcı tarafından sağlandı. Orijinal paketteki LICENSE korunur. Mevcut proje dosyaları önceki sürümlerden taşındı.

## Önceki README

# Winamp 2.95 — Android Auto / Kullanıcı Betiği Yöneticisi

Bu proje, kullanıcının Android Auto'da çalıştığını doğruladığı **Mini** uygulaması temel alınarak genişletildi. Android Auto görünürlüğü resmî tarayıcı desteği değildir, farklı cihazlarda garanti edilmez. **Yalnızca park hâlinde kullanın.** Açılış onayı aracın gerçek hızını doğrulamaz.

## İstenen özellikler

- Uygulama adı: **Winamp 2.95**; paket kimliği korunmuştur: `com.mini.auto`. Önceden kurulan Mini'nin yerini alabilmesi için sürüm kodu artırılmıştır. Android, imza farklıysa eski uygulamanın kaldırılmasını isteyebilir; kaldırma kayıtlı betikleri de siler.
- Uygulama simgesi: **kullanıcının gönderdiği orijinal Winamp yıldırım ve eşkenar dörtgen çerçeve**. Ekran görüntüsündeki gri zemin ve alttaki yazı çıkarılmıştır; PNG alfa kanalı saydamdır. Üretilen alternatif kulaklıklı tasarım kullanılmamıştır.
- Ana sayfa: `https://music.youtube.com/`.
- Dahili kod: **Winamp - YouTube Music 2.95.37**; yüklenen `.txt` ile bire bir aynı, 1.5 MB boyutundaki kullanıcı betiği.
- `⌘ Kodlar` menüsü: yeni JavaScript yazma; `.js` ve `.txt` dosyası içe alma; kodu düzenleme, dosyadan güncelleme, etkinleştirme/devre dışı bırakma, silme, varsayılan Winamp betiğini geri yükleme ve JavaScript hata günlüğünü kopyalama.
- `// @match` ve `// @include` eşleşmeleri ile uygun **HTTPS** sayfalarında çalıştırılır. `@exclude` ve `@exclude-match` de desteklenir.
- Betik dosyaları uygulama içinde özel yerel depolamada saklanır. Sayfayı yeniledikten sonra yapılan betik değişiklikleri uygulanır.
- Büyük Winamp kodu Android WebView `evaluateJavascript` aktarım sınırlarını aşmamak için **20 KB parçalara** bölünüp sayfa içinde birleştirilerek çalıştırılır.

## Derleme

JDK 17, Gradle 8.11.1, Android Gradle Plugin 8.9.2, compile/target SDK 35, min SDK 35.

```bash
./gradlew :app:assembleDebug
```

Oluşan dosya: `app/build/outputs/apk/debug/app-debug.apk`. Android projesi bir ZIP olarak kullanıcının HTML GitHub APK oluşturucusuna verilebilir. APK burada derlenip cihaz üzerinde test **edilmedi**.

## Teknik sınırlamalar

- Bu bir Tampermonkey klonu değil: `@grant none` biçimindeki sayfa içi JavaScript desteğidir. `GM_*`, otomatik uzak güncelleme, `@require`, `@resource` gibi Tampermonkey API'leri desteklenmez.
- YouTube Music, Android WebView sürümü, oturum açma politikası, DRM veya ses yakalama kısıtları nedeniyle betiğin tüm Winamp/MilkDrop özelliklerinin çalışması garanti değildir.
- Eski uygulama kaldırılırsa özel depolamadaki betik değişiklikleri kaybolur. Kaynakları koruyun.
- Geliştirme tabanı AABrowser yapılandırmasından uyarlanmıştır; GPL-3.0 lisansı/LICENSE ektedir. Resmî araç içi tarayıcı uygulaması değildir.

## 2.95.2 derleme düzeltmesi

GitHub run 45756738768 üzerindeki `ScriptRepository.java:111` derleme hatası giderildi: `JSONArray.put(index, value)` tarafından bildirilen `JSONException`, `IOException` içine alınarak yakalanıyor. Kod yöneticisi/Winamp betiği/simge değiştirilmedi. Derleme doğrulaması GitHub üzerinde henüz tamamlanmadı.

## 2.95.3 menü ve betik çalıştırma düzeltmesi

- Android `AlertDialog` penceresinde `setMessage` ile `setItems` birlikte kullanıldığında, seçim satırlarının görünmemesine yol açan iki menü hatası düzeltildi. Artık **⌘ Kodlar → Dosyadan kod yükle** ve kayıtlı kodu düzenle/etkinleştir/sil işlemleri görünür.
- Winamp dahil tüm etkin betikler eşleşen HTTPS sayfalara ardışık küçük parçalar hâlinde gönderilir. Her parçanın WebView tarafından alındığı doğrulanır. Sonuç ve hatalar ekranın altındaki durum satırına ve **Kodlar → Çalıştırma durumu / JavaScript hata günlüğü** bölümüne yazılır.
- Ana sayfa `https://music.youtube.com/` ve kullanıcının orijinal saydam Winamp simgesi korunmuştur.
- Bu sürüm cihazda veya gerçek GitHub derlemesinde henüz doğrulanmadı; sonuç için yeni rapor gerekir. YouTube Music CSP / WebView kısıtları varsa yeni hata günlüğü sorunun kaynağını gösterebilir.

## 2.95.4 — Trusted Types / büyük betik aktarımı düzeltmesi (26 Kasım 2026)

Kullanıcının gönderdiği canlı hata kaydı, daha önceki betik çalıştırma yönteminin **YouTube Music Trusted Types** politikasına takıldığını (`EvalError: ... TrustedScript`) ve **Base64 parça aktarımının** navigasyon sırasında kesilebildiğini (`atob: InvalidCharacterError`, `missing`) gösterdi. `Permissions policy violation: unload` uyarıları asıl sorun değildir.

Bu sürümde:

- `eval`, `atob`, `new Function` veya büyük Base64 parça birleştirmesi **betik çalıştırıcısından kaldırıldı**.
- Betikler AndroidX WebKit'in `WebViewCompat.addDocumentStartJavaScript` özelliğiyle **kaynak kodu olarak** kayıt edilir; her yeni sayfa yüklenmesinde WebView doğrudan yürütür. Sayfa içi Trusted Types politikasını gevşetmez.
- `@match`, `@include`, `@exclude`, `@exclude-match` ve `@run-at` eşleşmeleri denetlenir; yalnızca HTTPS adreslerinde ve üst çerçevede yürütme hedeflenir.
- Her kodun durumu `⌘ Kodlar → Çalıştırma durumu / JavaScript hata günlüğü` alanına kaydedilir.
- Kullanıcının kayıtlı betikleri ve simgesi korunur. `⌘ Kodlar → ⚡ Winamp 2.95.37'yi etkinleştir` seçeneği, eski denemelerde devre dışı kalmış dahili kodu tek dokunuşta etkinleştirir. Aynı Winamp betiğini ikinci kez içe aktarmaya gerek yoktur.
- `androidx.webkit:webkit:1.14.0` bağımlılığı eklendi. Android System WebView `DOCUMENT_START_SCRIPT` özelliğini desteklemiyorsa **açık hata** gösterilir; betik çalışmış gibi bildirilmez.

**Doğrulama:** Kaynak JS'nin SHA-256'sı eski paket ile aynı; ikon da değişmedi. Gerçek 1,5 MB Winamp kaynak kodunu içeren Java ile üretilmiş enjeksiyon çıktısı Node.js sözdizimi testinden geçti. Basit betik, URL `@match` ve `document-idle` simülasyon testlerinden geçti. Android SDK bu çalışma ortamında bulunmadığından gerçek APK derleme ve Android Auto cihaz testi henüz gerçekleştirilemedi. Bir sonraki GitHub derlemesi bunu doğrulayacaktır.

**Kalan sınırlama:** Web sitesinin Trusted Types güvenliği içinde Winamp'ın içindeki Butterchurn/MilkDrop kütüphanesi bazı efektleri kendi `new Function(...)` çağrılarıyla oluşturuyor. Yeni yöntem betiğin **başlatılmasını** düzeltir; MilkDrop'un dinamik fonksiyon oluşturmasının tamamını otomatik olarak düzelteceğini garanti etmez. Ayrıca Android WebView müzik akışını/sesi doğrudan yakalamayı sınırlayabilir.
