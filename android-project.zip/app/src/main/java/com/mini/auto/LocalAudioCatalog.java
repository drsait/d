package com.mini.auto;

import android.Manifest;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;

import java.util.ArrayList;
import java.util.List;

/** Only genuine audio files indexed on the phone. Never scrapes YouTube Music streams. */
final class LocalAudioCatalog {
    static final String ROOT = "winamp:root";
    static final String ALL = "winamp:all";

    static MediaItem folder(String id, String name) {
        return new MediaItem.Builder()
            .setMediaId(id)
            .setMediaMetadata(new MediaMetadata.Builder()
                .setTitle(name)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .build())
            .build();
    }

    static List<MediaItem> songs(Context context) {
        ArrayList<MediaItem> result = new ArrayList<>();
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return result;
        }
        String[] projection = {MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST};
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        try (Cursor cursor = context.getContentResolver().query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection, selection, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
            if (cursor == null) return result;
            int idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
            int titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
            int artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
            while (cursor.moveToNext()) {
                long id = cursor.getLong(idCol);
                String title = cursor.getString(titleCol);
                String artist = cursor.getString(artistCol);
                Uri uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
                result.add(new MediaItem.Builder()
                    .setMediaId("winamp:song:" + id)
                    .setUri(uri)
                    .setMediaMetadata(new MediaMetadata.Builder()
                        .setTitle(title == null ? "Adsız" : title)
                        .setArtist(artist == null ? "Bilinmiyor" : artist)
                        .setIsPlayable(true)
                        .setIsBrowsable(false)
                        .build())
                    .build());
                // Android Auto lists should be bounded to avoid overloading legacy browser clients.
                if (result.size() >= 2000) break;
            }
        } catch (SecurityException | IllegalArgumentException ex) {
            android.util.Log.w("WinampMedia", "Müzik kütüphanesi okunamadı", ex);
        }
        return result;
    }
}
