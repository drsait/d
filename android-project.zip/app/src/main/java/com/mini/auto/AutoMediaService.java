package com.mini.auto;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.LibraryResult;
import androidx.media3.session.MediaLibraryService;
import androidx.media3.session.MediaSession;

import com.google.common.collect.ImmutableList;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Real Android Auto media endpoint for user-owned local audio on the phone.
 * It does not proxy, rip, or claim to play YouTube Music WebView audio.
 * The original WebView+userscripts UI remains in MainActivity (parked use).
 */
@UnstableApi
public final class AutoMediaService extends MediaLibraryService {
    private ExoPlayer player;
    private MediaLibrarySession librarySession;

    private final MediaLibrarySession.Callback callback = new MediaLibrarySession.Callback() {
        @Override
        public ListenableFuture<LibraryResult<MediaItem>> onGetLibraryRoot(
                MediaLibrarySession session, MediaSession.ControllerInfo browser, LibraryParams params) {
            return Futures.immediateFuture(LibraryResult.ofItem(
                LocalAudioCatalog.folder(LocalAudioCatalog.ROOT, "Winamp 2.95"), params));
        }

        @Override
        public ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> onGetChildren(
                MediaLibrarySession session, MediaSession.ControllerInfo browser,
                String parentId, int page, int pageSize, LibraryParams params) {
            List<MediaItem> items;
            if (LocalAudioCatalog.ROOT.equals(parentId)) {
                items = Collections.singletonList(LocalAudioCatalog.folder(
                    LocalAudioCatalog.ALL, "Telefondaki Müzikler"));
            } else if (LocalAudioCatalog.ALL.equals(parentId)) {
                items = LocalAudioCatalog.songs(AutoMediaService.this);
            } else {
                items = Collections.emptyList();
            }
            long start = (long) page * pageSize;
            int from = (int) Math.min(items.size(), start);
            int to = (int) Math.min(items.size(), start + pageSize);
            return Futures.immediateFuture(LibraryResult.ofItemList(items.subList(from, to), params));
        }

        @Override
        public ListenableFuture<LibraryResult<MediaItem>> onGetItem(
                MediaLibrarySession session, MediaSession.ControllerInfo browser, String mediaId) {
            if (LocalAudioCatalog.ROOT.equals(mediaId))
                return Futures.immediateFuture(LibraryResult.ofItem(
                    LocalAudioCatalog.folder(LocalAudioCatalog.ROOT, "Winamp 2.95"), null));
            if (LocalAudioCatalog.ALL.equals(mediaId))
                return Futures.immediateFuture(LibraryResult.ofItem(
                    LocalAudioCatalog.folder(LocalAudioCatalog.ALL, "Telefondaki Müzikler"), null));
            for (MediaItem song : LocalAudioCatalog.songs(AutoMediaService.this)) {
                if (song.mediaId.equals(mediaId))
                    return Futures.immediateFuture(LibraryResult.ofItem(song, null));
            }
            return Futures.immediateFuture(LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE, null));
        }

        /** Resolve media IDs from legacy Android Auto playFromMediaId, not a fake player state. */
        @Override
        public ListenableFuture<MediaSession.MediaItemsWithStartPosition> onSetMediaItems(
                MediaSession session, MediaSession.ControllerInfo controller,
                List<MediaItem> requested, int startIndex, long startPositionMs) {
            List<MediaItem> all = LocalAudioCatalog.songs(AutoMediaService.this);
            if (requested.isEmpty()) {
                return Futures.immediateFuture(new MediaSession.MediaItemsWithStartPosition(
                    Collections.emptyList(), 0, C.TIME_UNSET));
            }
            String id = requested.get(Math.max(0, Math.min(requested.size()-1,
                    startIndex == C.INDEX_UNSET ? 0 : startIndex))).mediaId;
            int chosen = -1;
            for (int i = 0; i < all.size(); i++) {
                if (all.get(i).mediaId.equals(id)) { chosen = i; break; }
            }
            if (chosen >= 0) {
                // Android Auto next/previous now traverses the user's actual local songs.
                return Futures.immediateFuture(new MediaSession.MediaItemsWithStartPosition(
                    all, chosen, Math.max(0, startPositionMs == C.TIME_UNSET ? 0 : startPositionMs)));
            }
            // Explicitly refuse unknown / WebView-only media IDs.
            return Futures.immediateFuture(new MediaSession.MediaItemsWithStartPosition(
                Collections.emptyList(), 0, C.TIME_UNSET));
        }

        @Override
        public ListenableFuture<List<MediaItem>> onAddMediaItems(
                MediaSession session, MediaSession.ControllerInfo controller, List<MediaItem> requested) {
            List<MediaItem> all = LocalAudioCatalog.songs(AutoMediaService.this);
            ArrayList<MediaItem> valid = new ArrayList<>();
            for (MediaItem incoming : requested) {
                for (MediaItem song : all) {
                    if (song.mediaId.equals(incoming.mediaId)) {
                        valid.add(song); break;
                    }
                }
            }
            return Futures.immediateFuture(valid);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        player = new ExoPlayer.Builder(this).build();
        player.setHandleAudioBecomingNoisy(true);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 0, open,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        librarySession = new MediaLibrarySession.Builder(this, player, callback)
            .setSessionActivity(pending).build();
    }

    @Override public MediaLibrarySession onGetSession(MediaSession.ControllerInfo info) {
        return librarySession;
    }

    @Override public void onDestroy() {
        if (librarySession != null) {
            librarySession.release();
            librarySession = null;
        }
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
