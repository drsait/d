package com.mini.auto;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.util.Base64;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.ConsoleMessage;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

/** Mini: park-hâlinde Android Auto WebView browser with locally managed userscripts. */
public final class MainActivity extends Activity {
    private static final String HOME = "https://music.youtube.com/";
    private static final int REQUEST_IMPORT = 821;
    private WebView browser;
    private EditText address;
    private ProgressBar progress;
    private Button backButton, forwardButton;
    private TextView scriptStatus;
    private ScriptRepository scripts;
    private final ArrayList<String> scriptLog = new ArrayList<>();
    private boolean unlockedThisSession = false;
    private String pendingUrl = null;
    private String updateScriptId = null;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(11, 24, 39));
        getWindow().setNavigationBarColor(Color.rgb(11, 24, 39));
        try { scripts = new ScriptRepository(this); }
        catch (IOException e) {
            new AlertDialog.Builder(this).setTitle("Winamp 2.95 kod deposu hatası")
                .setMessage(e.toString()).setPositiveButton("Kapat", (d, w) -> finish()).show();
            return;
        }
        String link = getIntent() != null ? getIntent().getDataString() : null;
        if (link != null && link.startsWith("https://")) pendingUrl = link;
        showParkedConfirmation();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String link = intent != null ? intent.getDataString() : null;
        if (link != null && link.startsWith("https://")) {
            if (unlockedThisSession && browser != null) browser.loadUrl(link);
            else pendingUrl = link;
        }
    }

    private void record(String msg) {
        if (scriptLog.size() >= 100) scriptLog.remove(0);
        scriptLog.add(msg);
    }
    private int dp(float n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }
    private LinearLayout column() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); return c;
    }
    private Button makeButton(String label, Runnable callback) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false); b.setTextSize(14);
        b.setMinHeight(dp(48)); b.setOnClickListener(v -> callback.run());
        return b;
    }
    private TextView text(String value, int size) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(Color.WHITE);
        return t;
    }
    private void message(String value) { Toast.makeText(this, value, Toast.LENGTH_LONG).show(); }

    private void showParkedConfirmation() {
        unlockedThisSession = false;
        LinearLayout panel = column();
        panel.setPadding(dp(22),dp(22),dp(22),dp(22));
        panel.setGravity(Gravity.CENTER);
        panel.setBackgroundColor(Color.rgb(13,25,40));
        TextView title = text("Winamp 2.95 • Kod Yöneticisi", 27);
        title.setTypeface(null, Typeface.BOLD); title.setGravity(Gravity.CENTER);
        panel.addView(title, new LinearLayout.LayoutParams(-1,dp(58)));
        TextView warning = text("Yalnızca park hâlinde kullanın. Winamp 2.95 aracın hızını/park konumunu doğrulayamaz. Kod düzenleme ve web sayfasında gezinme sürüş sırasında yapılmamalıdır.\n\nYalnızca güvendiğiniz kodları çalıştırın: betikler açtığınız sitelerin içeriğine erişebilir.", 16);
        warning.setGravity(Gravity.CENTER); warning.setPadding(0,dp(8),0,dp(18));
        panel.addView(warning);
        panel.addView(makeButton("Araç park hâlinde — YouTube Music'i aç", () -> {
            unlockedThisSession = true; initBrowser();
        }), new LinearLayout.LayoutParams(-1,dp(68)));
        setContentView(panel);
    }

    private void initBrowser() {
        LinearLayout root = column(); root.setBackgroundColor(Color.rgb(12,22,37));
        LinearLayout top = new LinearLayout(this);
        top.setPadding(dp(7),dp(5),dp(7),dp(1));
        top.setGravity(Gravity.CENTER_VERTICAL);
        address = new EditText(this);
        address.setSingleLine(true); address.setSelectAllOnFocus(true);
        address.setTextSize(15); address.setHint("Adres veya arama");
        address.setHintTextColor(Color.LTGRAY); address.setTextColor(Color.WHITE);
        address.setBackgroundColor(Color.rgb(38,54,73));
        address.setPadding(dp(12),dp(9),dp(12),dp(9));
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        top.addView(address, new LinearLayout.LayoutParams(0,dp(51),1));
        top.addView(makeButton("Git", this::navigate),new LinearLayout.LayoutParams(dp(64),dp(51)));
        root.addView(top);
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); root.addView(progress,new LinearLayout.LayoutParams(-1,dp(3)));

        browser = new WebView(this);
        browser.setBackgroundColor(Color.BLACK);
        browser.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setSafeBrowsingEnabled(true);
        // Media requires a user interaction on sites that enforce autoplay policies;
        // this flag enables compatibility when the user has opened Mini while parked.
        settings.setMediaPlaybackRequiresUserGesture(false);
        WebView.setWebContentsDebuggingEnabled(false);
        browser.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String scheme = r.getUrl().getScheme();
                if ("https".equalsIgnoreCase(scheme)) return false;
                if ("http".equalsIgnoreCase(scheme)) {
                    v.loadUrl("https://" + r.getUrl().toString().substring(7));
                } else message("Desteklenmeyen bağlantı engellendi");
                return true;
            }
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                updateUrl(url); updateButtons();
            }
            @Override public void onPageFinished(WebView v, String url) {
                updateUrl(url); updateButtons(); injectMatchingScripts(v, url);
            }
            @Override public void onReceivedSslError(WebView v, SslErrorHandler h, SslError e) {
                h.cancel(); message("SSL sertifika hatası: bağlantı reddedildi");
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) {
                if (progress != null) {
                    progress.setProgress(p);
                    progress.setVisibility(p >= 100 ? View.INVISIBLE : View.VISIBLE);
                }
                updateButtons();
            }
            @Override public boolean onConsoleMessage(ConsoleMessage c) {
                if (c.messageLevel() == ConsoleMessage.MessageLevel.ERROR ||
                    c.messageLevel() == ConsoleMessage.MessageLevel.WARNING ||
                    c.message().startsWith("[Mini]")) {
                    record(c.messageLevel() + " " + c.message() + " (" + c.sourceId() + ":" + c.lineNumber() + ")");
                }
                return false;
            }
        });
        root.addView(browser,new LinearLayout.LayoutParams(-1,0,1));
        scriptStatus = text("Kodlar yüklenmeyi bekliyor…", 12);
        scriptStatus.setTextColor(Color.rgb(180, 205, 232));
        scriptStatus.setSingleLine(true);
        scriptStatus.setEllipsize(android.text.TextUtils.TruncateAt.END);
        scriptStatus.setPadding(dp(10), dp(2), dp(10), dp(2));
        root.addView(scriptStatus, new LinearLayout.LayoutParams(-1, dp(23)));
        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(dp(3),0,dp(3),dp(4));
        backButton = makeButton("◀", () -> { if (browser.canGoBack()) browser.goBack(); });
        forwardButton = makeButton("▶", () -> { if (browser.canGoForward()) browser.goForward(); });
        Button reload = makeButton("⟳", () -> browser.reload());
        Button home = makeButton("⌂", () -> browser.loadUrl(HOME));
        Button code = makeButton("⌘ Kodlar", this::showScripts);
        for (Button b : new Button[]{backButton,forwardButton,reload,home,code}) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,dp(57),b==code?1.55f:1f);
            p.setMargins(dp(2),0,dp(2),0); actions.addView(b,p);
        }
        root.addView(actions);
        setContentView(root);
        address.setOnEditorActionListener((v,actionId,event) -> {
            if (actionId==EditorInfo.IME_ACTION_GO || actionId==EditorInfo.IME_ACTION_DONE) {
                navigate(); return true;
            }
            return false;
        });
        browser.loadUrl(pendingUrl!=null?pendingUrl:HOME);
        pendingUrl=null;
        updateButtons();
    }

    /**
     * Codes are transferred sequentially in small chunks to avoid large WebView
     * IPC transactions. Evaluate callbacks also report the ACTUAL browser result.
     * There is no JavaScriptInterface available to untrusted websites.
     */
    private void setScriptStatus(String status) {
        if (scriptStatus != null) scriptStatus.setText(status);
    }

    private void injectMatchingScripts(WebView view, String pageUrl) {
        if (!unlockedThisSession || view == null || pageUrl == null) return;
        try {
            List<ScriptRepository.Script> matching = new ArrayList<>();
            for (ScriptRepository.Script script : scripts.list()) {
                if (ScriptRepository.applies(script, pageUrl)) matching.add(script);
            }
            if (matching.isEmpty()) {
                record("Bu sayfayla eşleşen etkin kod yok: " + pageUrl);
                setScriptStatus("Etkin eşleşen kod bulunmadı • ⌘ Kodlar");
                return;
            }
            record("Eşleşen kod sayısı: " + matching.size() + " → " + pageUrl);
            loadScriptAt(view, pageUrl, matching, 0);
        } catch (Exception e) {
            record("Kod listesi hatası: " + e);
            setScriptStatus("⚠ Kod listesi hatası • ⌘ Kodlar > Hata günlüğü");
        }
    }

    private void loadScriptAt(WebView view, String pageUrl,
                              List<ScriptRepository.Script> matching, int position) {
        if (view != browser || !unlockedThisSession || isFinishing()) return;
        if (position >= matching.size()) return;
        ScriptRepository.Script item = matching.get(position);
        setScriptStatus("Kod yükleniyor (" + (position + 1) + "/" + matching.size() + "): " + item.name);
        String key = JSONObject.quote(item.id);
        String encoded = Base64.encodeToString(
            item.code.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        String init = "(function(){var k=" + key + ";" +
            "var chunks=window.__MINI_USERSCRIPT_CHUNKS__||" +
            "(window.__MINI_USERSCRIPT_CHUNKS__={});chunks[k]='';" +
            "return 'initialized'})()";
        view.evaluateJavascript(init, result -> {
            if (view != browser || isFinishing()) return;
            sendChunk(view, pageUrl, matching, position, item, key, encoded, 0);
        });
    }

    private void sendChunk(WebView view, String pageUrl,
                           List<ScriptRepository.Script> matching, int position,
                           ScriptRepository.Script item, String key,
                           String encoded, int offset) {
        if (view != browser || !unlockedThisSession || isFinishing()) return;
        if (offset >= encoded.length()) {
            finishScript(view, pageUrl, matching, position, item, key);
            return;
        }
        final int CHUNK = 16_000;
        int next = Math.min(offset + CHUNK, encoded.length());
        String chunk = encoded.substring(offset, next);
        String expression = "(function(){var k=" + key + ";" +
            "var c=window.__MINI_USERSCRIPT_CHUNKS__;" +
            "if(!c||typeof c[k]!=='string')return 'missing';" +
            "c[k]+=" + JSONObject.quote(chunk) + ";return 'ok'})()";
        view.evaluateJavascript(expression, response -> {
            if (view != browser || isFinishing()) return;
            if (!"\"ok\"".equals(response)) {
                record("Kod aktarımı yarıda kesildi: " + item.name +
                    " / " + offset + " / yanıt: " + response);
                setScriptStatus("⚠ Kod aktarımı hatası • ⌘ Kodlar > Hata günlüğü");
                return;
            }
            sendChunk(view, pageUrl, matching, position, item, key, encoded, next);
        });
    }

    private void finishScript(WebView view, String pageUrl,
                              List<ScriptRepository.Script> matching, int position,
                              ScriptRepository.Script item, String key) {
        String expression = "(function(){var k=" + key + ";" +
            "var chunks=window.__MINI_USERSCRIPT_CHUNKS__||{};" +
            "var reg=window.__MINI_USERSCRIPT_REGISTRY__||" +
            "(window.__MINI_USERSCRIPT_REGISTRY__={});" +
            "if(!chunks[k])return JSON.stringify({ok:false,error:'Aktarılan kod bulunamadı'});" +
            "try{var binary=atob(chunks[k]);var bytes=new Uint8Array(binary.length);" +
            "for(var i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);" +
            "var src=new TextDecoder('utf-8').decode(bytes);" +
            "(0,eval)(src);reg[k]=true;" +
            "return JSON.stringify({ok:true,winamp:!!window.__WINAMP_YTM_LOADED__});" +
            "}catch(e){reg[k]=false;var err=String(e&&e.stack||e);" +
            "console.error('[Mini] '+k+': '+err);" +
            "return JSON.stringify({ok:false,error:err});" +
            "}finally{delete chunks[k];}})()";
        view.evaluateJavascript(expression, response -> {
            if (view != browser || isFinishing()) return;
            try {
                String inner = (String) new org.json.JSONTokener(response).nextValue();
                JSONObject result = new JSONObject(inner);
                if (result.optBoolean("ok")) {
                    boolean isWinamp = ScriptRepository.WINAMP_ID.equals(item.id);
                    boolean started = result.optBoolean("winamp");
                    String status = isWinamp && !started ? "⚠ Winamp çalışmadı" : "✓ Kod çalıştırıldı";
                    record(status + ": " + item.name + " → " + pageUrl);
                    setScriptStatus(status + " • " + item.name);
                } else {
                    String error = result.optString("error", "Bilinmeyen JavaScript hatası");
                    record("KOD ÇALIŞTIRMA HATASI: " + item.name + ": " + error);
                    setScriptStatus("⚠ Kod hatası • ⌘ Kodlar > Hata günlüğü");
                }
            } catch (Exception e) {
                record("Kod yanıtı okunamadı: " + item.name + " → " + response + " / " + e);
                setScriptStatus("⚠ Kod yanıtı alınamadı • ⌘ Kodlar > Hata günlüğü");
            }
            loadScriptAt(view, pageUrl, matching, position + 1);
        });
    }

    private void reloadForScripts() {
        if (browser != null) browser.reload();
    }

    private void showScripts() {
        if (!unlockedThisSession) return;
        try {
            List<ScriptRepository.Script> saved = scripts.list();
            ArrayList<String> choices = new ArrayList<>();
            choices.add("＋ Yeni kod ekle (yazarak)");
            choices.add("📂 Dosyadan kod yükle (.js / .txt)");
            choices.add("↺ Orijinal Winamp 2.95.37'yi geri yükle");
            choices.add("≡ Çalıştırma durumu / JavaScript hata günlüğü");
            for (ScriptRepository.Script s : saved)
                choices.add((s.enabled ? "● " : "○ ") + s.name + "\n" + s.matchSummary());
            new AlertDialog.Builder(this)
                .setTitle("Winamp 2.95 • Kod Yöneticisi (" + saved.size() + ")")
                // Android AlertDialog: setMessage + setItems kullanılırsa seçenek listesi gizlenebilir.
                // Kullanıcı kod ekleme menüsünü göremiyordu. Yalnızca setItems kullan.
                .setItems(choices.toArray(new String[0]), (dialog, which) -> {
                    if (which==0) editScript(null);
                    else if (which==1) selectScriptFile(null);
                    else if (which==2) confirmRestore();
                    else if (which==3) showScriptLog();
                    else actionForScript(saved.get(which-4));
                }).setNegativeButton("Kapat",null).show();
        } catch (IOException e) { message("Kodlar okunamadı: " + e.getMessage()); }
    }

    private void actionForScript(ScriptRepository.Script s) {
        String[] actions = {s.enabled ? "Devre dışı bırak" : "Etkinleştir",
            "Kodu düzenle", "Dosyadan güncelle", "Sil", "İptal"};
        new AlertDialog.Builder(this).setTitle(s.name)
            .setItems(actions,(dialog,index) -> {
                if (index==0) {
                    s.enabled=!s.enabled;
                    try { scripts.save(s); reloadForScripts(); showScripts(); }
                    catch (IOException e) { message(e.getMessage()); }
                } else if (index==1) editScript(s);
                else if (index==2) selectScriptFile(s.id);
                else if (index==3) {
                    new AlertDialog.Builder(this).setTitle("Kodu sil")
                        .setMessage(s.name+" silinsin mi? Bu işlem geri alınamaz.")
                        .setNegativeButton("Vazgeç",null)
                        .setPositiveButton("Sil",(d,w) -> {
                            try { scripts.delete(s.id); reloadForScripts(); showScripts(); }
                            catch (IOException e) { message(e.getMessage()); }
                        }).show();
                }
            }).show();
    }

    private void editScript(ScriptRepository.Script existing) {
        ScriptRepository.Script s = existing != null ? existing :
            new ScriptRepository.Script("", "Yeni Mini Kodu", ScriptRepository.template(), true);
        LinearLayout layout = column();
        layout.setPadding(dp(10),dp(8),dp(10),dp(2));
        CheckBox enabled = new CheckBox(this);
        enabled.setText("Etkin"); enabled.setChecked(s.enabled);
        layout.addView(enabled);
        TextView note = text("Tampermonkey biçiminde // @name ve // @match satırları kullan. @grant none desteklenir. Büyük betikler için dosyadan güncelleme önerilir.",13);
        note.setTextColor(Color.DKGRAY);
        layout.addView(note);
        EditText editor = new EditText(this);
        editor.setTextSize(12);
        editor.setTypeface(Typeface.MONOSPACE);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setMinLines(12);
        editor.setMaxLines(23);
        editor.setHorizontallyScrolling(true);
        boolean huge = s.code.length() > 230_000;
        final boolean[] fullyLoaded = {!huge};
        if (huge) {
            editor.setText("// Büyük kod ("+s.code.length()+" karakter). Düzenlemek için aşağıdaki düğmeye basın.\n// Dosyadan güncelleme daha hızlıdır.");
            Button showLarge = makeButton("Büyük kodu düzenleyiciye yükle", () -> {
                fullyLoaded[0] = true;
                editor.setText(s.code);
                editor.setSelection(0);
            });
            layout.addView(showLarge);
        } else editor.setText(s.code);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(editor);
        layout.addView(scroll,new LinearLayout.LayoutParams(-1,dp(280)));
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle(existing==null ? "Yeni kod" : "Düzenle: "+s.name)
            .setView(layout)
            .setPositiveButton("Kaydet",null)
            .setNegativeButton("Vazgeç",null)
            .setNeutralButton("Dosyadan güncelle",(d,w) -> selectScriptFile(existing==null?null:existing.id))
            .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                if (fullyLoaded[0]) s.code = editor.getText().toString();
                s.enabled = enabled.isChecked();
                scripts.save(s);
                record("Kaydedildi: " + s.name);
                dialog.dismiss();
                reloadForScripts(); showScripts();
            } catch (IOException ex) { message("Kaydetme hatası: " + ex.getMessage()); }
        }));
        dialog.show();
        // SetOnShowListener above is installed before show(); window may be compact on car display.
    }

    private void selectScriptFile(String replacementId) {
        updateScriptId = replacementId;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/plain","application/javascript","text/javascript","application/octet-stream"});
        try { startActivityForResult(intent,REQUEST_IMPORT); }
        catch (Exception e) { message("Dosya seçici açılamadı: "+e.getMessage()); }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode!=REQUEST_IMPORT || resultCode!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri = data.getData();
        try (InputStream in=getContentResolver().openInputStream(uri)) {
            if (in==null) throw new IOException("Dosya açılamadı");
            String content = ScriptRepository.readText(in);
            if (content.trim().isEmpty()) throw new IOException("Boş betik");
            if (!content.contains("@match") && !content.contains("@include")) {
                content = "// ==UserScript==\n// @name İçe Aktarılan Kod\n// @match https://music.youtube.com/*\n// @grant none\n// ==/UserScript==\n" + content;
            }
            ScriptRepository.Script target = null;
            if (updateScriptId!=null) {
                for (ScriptRepository.Script s:scripts.list())
                    if (s.id.equals(updateScriptId)) { target=s; break; }
            }
            if (target==null) target=new ScriptRepository.Script("", "İçe aktarılan kod",content,true);
            target.code=content;
            scripts.save(target);
            message("Kod kaydedildi: " + target.name);
            record("İçe aktarıldı: "+target.name);
            reloadForScripts();
        } catch (IOException e) { message("İçe aktarma hatası: "+e.getMessage()); }
        finally { updateScriptId=null; }
    }
    private void confirmRestore() {
        new AlertDialog.Builder(this).setTitle("Winamp 2.95.37'yi geri yükle")
            .setMessage("Orijinal Winamp betiği geri yüklenir. Var olan Winamp değişiklikleri silinir.")
            .setNegativeButton("Vazgeç",null)
            .setPositiveButton("Geri yükle",(d,w) -> {
                try { scripts.restoreWinamp(); reloadForScripts(); showScripts(); }
                catch(IOException e){message(e.getMessage());}
            }).show();
    }
    private void showScriptLog() {
        String report = "Sayfa: " + (browser == null ? "(yok)" : browser.getUrl()) +
            "\nDurum: " + (scriptStatus == null ? "(yok)" : scriptStatus.getText()) +
            "\n\n" + (scriptLog.isEmpty() ? "Henüz hata / işlem kaydı yok" :
            android.text.TextUtils.join("\n",scriptLog));
        new AlertDialog.Builder(this).setTitle("Winamp 2.95 betik günlüğü")
            .setMessage(report)
            .setPositiveButton("Kopyala",(d,w) -> {
                ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(ClipData.newPlainText("Winamp 2.95 betik günlüğü",report));
                message("Günlük panoya kopyalandı");
            }).setNegativeButton("Kapat",null).show();
    }

    private void updateUrl(String url) {
        if (address!=null && !address.hasFocus() && url!=null && url.startsWith("https://")) address.setText(url);
    }
    private void updateButtons() {
        if (browser==null || backButton==null) return;
        backButton.setEnabled(browser.canGoBack()); forwardButton.setEnabled(browser.canGoForward());
    }
    private void navigate() {
        if (address==null || browser==null) return;
        String raw=address.getText().toString().trim(); if(raw.isEmpty()) return;
        String url;
        if(raw.startsWith("https://")) url=raw;
        else if(raw.startsWith("http://")) url="https://"+raw.substring(7);
        else if(raw.contains(" ") || !raw.contains(".")) url="https://www.google.com/search?q="+Uri.encode(raw);
        else url="https://"+raw;
        browser.loadUrl(url); address.clearFocus();
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
            .hideSoftInputFromWindow(address.getWindowToken(),0);
    }
    @Override public void onBackPressed() {
        if (browser!=null && browser.canGoBack()) browser.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (browser!=null) {
            browser.stopLoading(); browser.setWebChromeClient(null); browser.setWebViewClient(null);
            ViewGroup parent=(ViewGroup)browser.getParent();
            if(parent!=null) parent.removeView(browser);
            browser.destroy(); browser=null;
        }
        super.onDestroy();
    }
}
