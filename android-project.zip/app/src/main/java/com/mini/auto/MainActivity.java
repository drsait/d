package com.mini.auto;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;

/**
 * Mini: Android Auto'da park halinde deneysel kullanım amaçlı HTTPS tarayıcı.
 * Android Auto manifest yaklaşımı AABrowser (GPL-3.0) projesinden uyarlanmıştır.
 * Sürüş hâli donanımdan doğrulanamaz; başlatma sırasında onay gerekir.
 */
public final class MainActivity extends Activity {
    private static final String HOME = "https://www.google.com";
    private WebView browser;
    private EditText address;
    private ProgressBar progress;
    private Button backButton, forwardButton, reloadButton;
    private LinearLayout root;
    private boolean unlockedThisSession = false;
    private String pendingUrl = null;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(11, 24, 39));
        getWindow().setNavigationBarColor(Color.rgb(11, 24, 39));
        String link = getIntent() != null ? getIntent().getDataString() : null;
        if (link != null && link.startsWith("https://")) pendingUrl = link;
        showParkedConfirmation();
    }

    @Override protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String link = intent != null ? intent.getDataString() : null;
        if (link != null && link.startsWith("https://")) {
            if (unlockedThisSession && browser != null) browser.loadUrl(link);
            else pendingUrl = link;
        }
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout column() {
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        return ll;
    }
    private Button makeButton(String text, Runnable callback) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setMinHeight(dp(52));
        b.setOnClickListener(v -> callback.run());
        return b;
    }
    private void showParkedConfirmation() {
        unlockedThisSession = false;
        LinearLayout panel = column();
        panel.setPadding(dp(22), dp(22), dp(22), dp(22));
        panel.setGravity(Gravity.CENTER);
        panel.setBackgroundColor(Color.rgb(13, 25, 40));
        TextView title = new TextView(this);
        title.setText("Mini");
        title.setTextSize(30);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        panel.addView(title, new LinearLayout.LayoutParams(-1, dp(58)));
        TextView warning = new TextView(this);
        warning.setText("Yalnızca araç güvenli şekilde park hâlindeyken kullanın. Uygulama aracın hızını veya park durumunu doğrulayamaz.\n\nSürüş sırasında web sayfalarını kullanmayın.");
        warning.setTextColor(Color.WHITE);
        warning.setTextSize(17);
        warning.setGravity(Gravity.CENTER);
        warning.setPadding(0, dp(10), 0, dp(20));
        panel.addView(warning);
        Button confirm = makeButton("Araç park hâlinde — Mini’yi aç", () -> {
            unlockedThisSession = true;
            initBrowser();
        });
        panel.addView(confirm, new LinearLayout.LayoutParams(-1, dp(72)));
        setContentView(panel);
    }

    private void initBrowser() {
        root = column();
        root.setBackgroundColor(Color.rgb(12, 22, 37));
        LinearLayout top = new LinearLayout(this);
        top.setPadding(dp(7), dp(6), dp(7), dp(2));
        top.setGravity(Gravity.CENTER_VERTICAL);
        address = new EditText(this);
        address.setSingleLine(true);
        address.setSelectAllOnFocus(true);
        address.setTextSize(16);
        address.setHint("Adres veya arama yaz");
        address.setHintTextColor(Color.LTGRAY);
        address.setTextColor(Color.WHITE);
        address.setBackgroundColor(Color.rgb(38, 54, 73));
        address.setPadding(dp(12), dp(10), dp(12), dp(10));
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        top.addView(address, new LinearLayout.LayoutParams(0, dp(56), 1f));
        Button go = makeButton("Git", this::navigate);
        LinearLayout.LayoutParams goParams = new LinearLayout.LayoutParams(dp(70), dp(56));
        top.addView(go, goParams);
        root.addView(top);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(4)));
        browser = new WebView(this);
        browser.setBackgroundColor(Color.WHITE);
        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSafeBrowsingEnabled(true);
        browser.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("https".equalsIgnoreCase(scheme)) return false;
                if ("http".equalsIgnoreCase(scheme)) {
                    String value = uri.toString();
                    view.loadUrl("https://" + value.substring(7));
                } else {
                    Toast.makeText(MainActivity.this, "Desteklenmeyen bağlantı", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                updateUrl(url);
                updateButtons();
            }
            @Override public void onPageFinished(WebView view, String url) {
                updateUrl(url);
                updateButtons();
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel(); // Sertifika hatasını görmezden gelme.
                Toast.makeText(MainActivity.this, "Güvensiz bağlantı engellendi", Toast.LENGTH_LONG).show();
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.INVISIBLE : View.VISIBLE);
                updateButtons();
            }
        });
        root.addView(browser, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(dp(5), 0, dp(5), dp(5));
        backButton = makeButton("◀ Geri", () -> { if (browser.canGoBack()) browser.goBack(); });
        forwardButton = makeButton("İleri ▶", () -> { if (browser.canGoForward()) browser.goForward(); });
        reloadButton = makeButton("⟳ Yenile", () -> { if (browser != null) browser.reload(); });
        Button homeButton = makeButton("⌂ Ana", () -> browser.loadUrl(HOME));
        for (Button b : new Button[]{backButton, forwardButton, reloadButton, homeButton}) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(62), 1f);
            p.setMargins(dp(2), dp(1), dp(2), dp(1));
            actions.addView(b, p);
        }
        root.addView(actions);
        setContentView(root);
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                navigate();return true;
            }
            return false;
        });
        browser.loadUrl(pendingUrl != null ? pendingUrl : HOME);
        pendingUrl = null;
        updateButtons();
    }

    private void updateUrl(String url) {
        if (address != null && !address.hasFocus() && url != null && url.startsWith("https://")) {
            address.setText(url);
        }
    }
    private void updateButtons() {
        if (browser == null || backButton == null) return;
        backButton.setEnabled(browser.canGoBack());
        forwardButton.setEnabled(browser.canGoForward());
    }
    private void navigate() {
        if (address == null || browser == null) return;
        String raw = address.getText().toString().trim();
        if (raw.isEmpty()) return;
        String url;
        if (raw.startsWith("https://")) url = raw;
        else if (raw.startsWith("http://")) url = "https://" + raw.substring(7);
        else if (raw.contains(" ") || !raw.contains(".")) url = "https://www.google.com/search?q=" + Uri.encode(raw);
        else url = "https://" + raw;
        browser.loadUrl(url);
        address.clearFocus();
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
            .hideSoftInputFromWindow(address.getWindowToken(), 0);
    }
    @Override public void onBackPressed() {
        if (browser != null && browser.canGoBack()) browser.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (browser != null) {
            browser.stopLoading();
            browser.setWebChromeClient(null);
            browser.setWebViewClient(null);
            ViewGroup parent = (ViewGroup)browser.getParent();
            if (parent != null) parent.removeView(browser);
            browser.destroy();
            browser = null;
        }
        super.onDestroy();
    }
}
