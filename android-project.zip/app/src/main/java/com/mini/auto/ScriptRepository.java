package com.mini.auto;

import android.content.Context;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Pattern;

/** Local userscript files + a small JSON index. No external account and no script downloads. */
public final class ScriptRepository {
    public static final int MAX_SCRIPT_BYTES = 8 * 1024 * 1024;
    public static final String WINAMP_ID = "builtin-winamp-29537";
    private static final String WINAMP_ASSET = "winamp_ytm_2.95.37.user.js";
    private final Context context;
    private final File dir;
    private final File index;

    public static final class Script {
        public String id;
        public String name;
        public String code;
        public boolean enabled;
        public Script(String id, String name, String code, boolean enabled) {
            this.id = id; this.name = name; this.code = code; this.enabled = enabled;
        }
        public String matchSummary() {
            List<String> patterns = tags(code, "match");
            if (patterns.isEmpty()) patterns = tags(code, "include");
            return patterns.isEmpty() ? "Eşleşme yok (çalıştırılmaz)" : patterns.get(0);
        }
    }

    public ScriptRepository(Context context) throws IOException {
        this.context = context.getApplicationContext();
        dir = new File(context.getFilesDir(), "mini_userscripts");
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Kodlar klasörü oluşturulamadı");
        index = new File(dir, "index.json");
        if (!index.isFile()) {
            JSONArray seed = new JSONArray();
            byte[] bytes = readAll(context.getAssets().open(WINAMP_ASSET));
            writeBytes(new File(dir, WINAMP_ID + ".js"), bytes);
            JSONObject row = new JSONObject();
            try {
                row.put("id", WINAMP_ID);
                row.put("name", "Winamp - YouTube Music 2.95.37");
                row.put("enabled", true);
                seed.put(row);
            } catch (Exception e) { throw new IOException(e); }
            writeBytes(index, seed.toString().getBytes(StandardCharsets.UTF_8));
        }
    }

    private static byte[] readAll(InputStream input) throws IOException {
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[16384]; int n;
            while ((n = in.read(b)) != -1) {
                if (out.size() + n > MAX_SCRIPT_BYTES) throw new IOException("Betik 8 MB sınırını aşıyor");
                out.write(b, 0, n);
            }
            return out.toByteArray();
        }
    }
    private static byte[] readFile(File f) throws IOException { return readAll(new FileInputStream(f)); }
    public static String readText(InputStream in) throws IOException {
        return new String(readAll(in), StandardCharsets.UTF_8);
    }
    private static void writeBytes(File file, byte[] content) throws IOException {
        File temp = new File(file.getParentFile(), file.getName() + ".tmp");
        try (FileOutputStream stream = new FileOutputStream(temp)) {
            stream.write(content);
            stream.getFD().sync();
        }
        if (!temp.renameTo(file)) {
            try (FileOutputStream stream = new FileOutputStream(file)) { stream.write(content); }
            if (!temp.delete()) temp.deleteOnExit();
        }
    }
    private JSONArray readIndex() throws IOException {
        try { return new JSONArray(new String(readFile(index), StandardCharsets.UTF_8)); }
        catch (Exception e) { throw new IOException("Betik dizini okunamadı", e); }
    }
    public synchronized List<Script> list() throws IOException {
        JSONArray data = readIndex();
        ArrayList<Script> list = new ArrayList<>();
        for (int i = 0; i < data.length(); ++i) {
            JSONObject row = data.optJSONObject(i);
            if (row == null) continue;
            String id = row.optString("id", "");
            if (!id.matches("[a-zA-Z0-9_-]{1,80}")) continue;
            File path = new File(dir, id + ".js");
            if (!path.isFile()) continue;
            String code = new String(readFile(path), StandardCharsets.UTF_8);
            list.add(new Script(id, row.optString("name", "Kod"), code, row.optBoolean("enabled", false)));
        }
        return list;
    }
    public synchronized void save(Script script) throws IOException {
        if (script.code == null || script.code.trim().isEmpty()) throw new IOException("Boş kod kaydedilemez");
        if (script.code.getBytes(StandardCharsets.UTF_8).length > MAX_SCRIPT_BYTES) throw new IOException("Betik 8 MB sınırını aşıyor");
        if (script.id == null || script.id.isEmpty()) script.id = UUID.randomUUID().toString().replace("-", "");
        if (!script.id.matches("[a-zA-Z0-9_-]{1,80}")) throw new IOException("Geçersiz betik kimliği");
        script.name = nameFromCode(script.code, script.name);
        JSONArray array = readIndex();
        boolean replaced = false;
        for (int i = 0; i < array.length(); i++) {
            JSONObject row = array.optJSONObject(i);
            if (row != null && script.id.equals(row.optString("id"))) {
                try {
                    array.put(i, toJSON(script));
                } catch (org.json.JSONException e) {
                    throw new IOException("Betik dizini güncellenemedi", e);
                }
                replaced = true;
                break;
            }
        }
        if (!replaced) array.put(toJSON(script));
        writeBytes(new File(dir, script.id + ".js"), script.code.getBytes(StandardCharsets.UTF_8));
        writeBytes(index, array.toString().getBytes(StandardCharsets.UTF_8));
    }
    private JSONObject toJSON(Script s) throws IOException {
        try {
            JSONObject o = new JSONObject();
            o.put("id", s.id); o.put("name", s.name); o.put("enabled", s.enabled);
            return o;
        } catch (Exception e) { throw new IOException(e); }
    }
    public synchronized void delete(String id) throws IOException {
        JSONArray array = readIndex(), next = new JSONArray();
        for (int i = 0; i < array.length(); i++) {
            JSONObject r = array.optJSONObject(i);
            if (r != null && !id.equals(r.optString("id"))) next.put(r);
        }
        writeBytes(index, next.toString().getBytes(StandardCharsets.UTF_8));
        File file = new File(dir, id + ".js");
        if (file.isFile() && !file.delete()) throw new IOException("Dosya silinemedi");
    }
    public synchronized void restoreWinamp() throws IOException {
        String code = new String(readAll(context.getAssets().open(WINAMP_ASSET)), StandardCharsets.UTF_8);
        save(new Script(WINAMP_ID, "Winamp - YouTube Music 2.95.37", code, true));
    }
    public static String nameFromCode(String code, String fallback) {
        List<String> names = tags(code, "name");
        return names.isEmpty() ? ((fallback == null || fallback.trim().isEmpty()) ? "Adsız kod" : fallback) : names.get(0);
    }
    private static List<String> tags(String code, String name) {
        ArrayList<String> results = new ArrayList<>();
        String[] lines = code.split("\\r?\\n", 120);
        int count = Math.min(120, lines.length);
        Pattern regex = Pattern.compile("^\\s*//\\s*@" + Pattern.quote(name) + "\\s+(.+?)\\s*$", Pattern.CASE_INSENSITIVE);
        for (int i = 0; i < count; i++) {
            java.util.regex.Matcher m = regex.matcher(lines[i]);
            if (m.find()) results.add(m.group(1).trim());
        }
        return results;
    }
    public static boolean applies(Script script, String url) {
        if (!script.enabled || !url.startsWith("https://")) return false;
        List<String> allow = tags(script.code, "match");
        allow.addAll(tags(script.code, "include"));
        if (allow.isEmpty()) return false; // Prevent silent execution on every site.
        boolean found = false;
        for (String p : allow) if (globMatch(p, url)) { found = true; break; }
        if (!found) return false;
        List<String> reject = tags(script.code, "exclude");
        reject.addAll(tags(script.code, "exclude-match"));
        for (String p : reject) if (globMatch(p, url)) return false;
        return true;
    }
    private static boolean globMatch(String wildcard, String url) {
        if ("<all_urls>".equals(wildcard)) return true;
        if (wildcard.length() > 500) return false;
        StringBuilder pattern = new StringBuilder("^");
        for (int i = 0; i < wildcard.length(); i++) {
            char c = wildcard.charAt(i);
            if (c == '*') pattern.append(".*");
            else pattern.append(Pattern.quote(String.valueOf(c)));
        }
        pattern.append("$");
        try { return Pattern.compile(pattern.toString(), Pattern.CASE_INSENSITIVE).matcher(url).matches(); }
        catch (Exception e) { return false; }
    }
    public static String template() {
        return "// ==UserScript==\\n// @name         Yeni Mini Kodu\\n// @match        https://music.youtube.com/*\\n// @run-at       document-idle\\n// @grant        none\\n// ==/UserScript==\\n\\n(function(){\\n  'use strict';\\n  console.log('Mini userscript çalıştı');\\n})();\\n".replace("\\n", "\n");
    }
}
