package com.example.mini;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import android.webkit.*;

public class MainActivity extends Activity {
    private WebView web;
    private EditText address;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        LinearLayout bar = new LinearLayout(this);
        address = new EditText(this);
        address.setSingleLine(true);
        address.setText("https://www.google.com");
        address.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        bar.addView(address, new LinearLayout.LayoutParams(0, -2, 1));
        Button go = button("Git", () -> navigate());
        bar.addView(go);
        main.addView(bar);
        LinearLayout actions = new LinearLayout(this);
        actions.addView(button("←", () -> {if(web.canGoBack()) web.goBack();}));
        actions.addView(button("→", () -> {if(web.canGoForward()) web.goForward();}));
        actions.addView(button("↻", () -> web.reload()));
        main.addView(actions);
        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) { address.setText(url); }
        });
        main.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(main);
        address.setOnEditorActionListener((v, actionId, event) -> { if(actionId==EditorInfo.IME_ACTION_GO || actionId==EditorInfo.IME_ACTION_DONE) {navigate();return true;}return false;});
        web.loadUrl("https://www.google.com");
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setOnClickListener(v -> action.run()); return b;
    }
    private void navigate() {
        String url = address.getText().toString().trim();
        if (!url.startsWith("https://") && !url.startsWith("http://")) url = "https://" + url;
        if(url.startsWith("https://")) web.loadUrl(url);
        else Toast.makeText(this, "Yalnızca HTTPS adresleri desteklenir", Toast.LENGTH_SHORT).show();
    }
    @Override public void onBackPressed() { if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { web.destroy(); super.onDestroy(); }
}
