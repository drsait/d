# ProGuard rules for WinampYTMAutoBrowser
