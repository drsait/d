// ==UserScript==
// @name         Winamp - YouTube Music
// @version      2.95.37-placeholder
// @description  Bu dosyayı kendi "Winamp - YouTube Music-2.95.37 (1).txt" dosyanızla değiştirin veya uygulama içindeki "Betik -> Dosyadan Yükle" menüsünü kullanın.
// @match        https://music.youtube.com/*
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';
    console.info('[Winamp YTM Tarayıcı] Varsayılan yer tutucu betik yüklendi. Uygulama içindeki "Betik" düğmesinden kendi .txt/.js dosyanızı yükleyebilirsiniz.');
})();
