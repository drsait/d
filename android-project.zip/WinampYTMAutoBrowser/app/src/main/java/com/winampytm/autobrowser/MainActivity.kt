package com.winampytm.autobrowser

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.winampytm.autobrowser.databinding.ActivityMainBinding
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var lastInjectedUrl: String? = null

    private val homeUrl = "https://music.youtube.com"
    private val desktopUserAgent =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

    private val openScriptLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                importScriptFromUri(uri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        applySystemInsets()
        setupWebView()
        setupToolbar()
        setupBackNavigation()

        val initialUrl = intent?.dataString?.takeIf {
            it.startsWith("http://") || it.startsWith("https://")
        } ?: homeUrl

        loadUrl(initialUrl)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val url = intent.dataString
        if (!url.isNullOrBlank() && (url.startsWith("http://") || url.startsWith("https://"))) {
            loadUrl(url)
        }
    }

    private fun applySystemInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.rootLayout) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = binding.webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        settings.javaScriptCanOpenWindowsAutomatically = true

        applyDesktopMode(ScriptManager.isDesktopMode(this), reload = false)

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(binding.webView, true)

        binding.webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString() ?: return false
                return !(url.startsWith("http://") || url.startsWith("https://"))
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                lastInjectedUrl = null
                if (!url.isNullOrBlank()) {
                    binding.etUrl.setText(url)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (!url.isNullOrBlank()) {
                    binding.etUrl.setText(url)
                    injectUserscriptIfMatching(url)
                }
            }
        }

        binding.webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                binding.progressBar.visibility =
                    if (newProgress in 1..99) View.VISIBLE else View.GONE
                binding.progressBar.progress = newProgress
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                binding.fullscreenContainer.addView(view)
                binding.fullscreenContainer.visibility = View.VISIBLE
            }

            override fun onHideCustomView() {
                hideFullscreenView()
            }
        }
    }

    private fun hideFullscreenView() {
        binding.fullscreenContainer.removeAllViews()
        binding.fullscreenContainer.visibility = View.GONE
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
    }

    private fun setupToolbar() {
        updateDesktopButtonState()

        binding.btnBack.setOnClickListener {
            if (binding.webView.canGoBack()) binding.webView.goBack()
        }
        binding.btnForward.setOnClickListener {
            if (binding.webView.canGoForward()) binding.webView.goForward()
        }
        binding.btnReload.setOnClickListener {
            lastInjectedUrl = null
            binding.webView.reload()
        }
        binding.btnHome.setOnClickListener {
            loadUrl(homeUrl)
        }
        binding.btnDesktop.setOnClickListener {
            val next = !ScriptManager.isDesktopMode(this)
            ScriptManager.setDesktopMode(this, next)
            applyDesktopMode(next, reload = true)
            updateDesktopButtonState()
        }
        binding.btnScript.setOnClickListener {
            showScriptManagerDialog()
        }
        binding.btnHideBar.setOnClickListener {
            binding.topToolbar.visibility = View.GONE
            binding.fabShowBar.visibility = View.VISIBLE
        }
        binding.fabShowBar.setOnClickListener {
            binding.topToolbar.visibility = View.VISIBLE
            binding.fabShowBar.visibility = View.GONE
        }

        binding.etUrl.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                val input = binding.etUrl.text.toString().trim()
                if (input.isNotEmpty()) {
                    val normalized = if (input.startsWith("http://") || input.startsWith("https://")) {
                        input
                    } else {
                        "https://$input"
                    }
                    loadUrl(normalized)
                }
                true
            } else {
                false
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> hideFullscreenView()
                    binding.webView.canGoBack() -> binding.webView.goBack()
                    else -> finish()
                }
            }
        })
    }

    private fun applyDesktopMode(enabled: Boolean, reload: Boolean) {
        val settings = binding.webView.settings
        settings.userAgentString = if (enabled) desktopUserAgent else null
        if (reload) {
            lastInjectedUrl = null
            binding.webView.reload()
        }
    }

    private fun updateDesktopButtonState() {
        val enabled = ScriptManager.isDesktopMode(this)
        binding.btnDesktop.alpha = if (enabled) 1.0f else 0.5f
    }

    private fun loadUrl(url: String) {
        binding.etUrl.setText(url)
        binding.webView.loadUrl(url)
    }

    private fun injectUserscriptIfMatching(url: String) {
        if (!ScriptManager.isEnabled(this)) return
        if (!url.startsWith("https://music.youtube.com")) return
        if (lastInjectedUrl == url) return

        lastInjectedUrl = url
        val rawScript = ScriptManager.getActiveScript(this)
        if (rawScript.isBlank()) return
        val wrapped = ScriptManager.wrapForInjection(rawScript)
        binding.webView.evaluateJavascript(wrapped, null)
    }

    private fun showScriptManagerDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_script_manager, null)
        val tvStatus = view.findViewById<TextView>(R.id.tvScriptStatus)
        val switchEnabled = view.findViewById<MaterialSwitch>(R.id.switchScriptEnabled)
        val btnLoadFile = view.findViewById<MaterialButton>(R.id.btnLoadFromFile)
        val btnUpdateUrl = view.findViewById<MaterialButton>(R.id.btnUpdateFromUrl)
        val btnEditCode = view.findViewById<MaterialButton>(R.id.btnEditCode)
        val btnReset = view.findViewById<MaterialButton>(R.id.btnResetDefault)

        val currentCode = ScriptManager.getActiveScript(this)
        val version = ScriptManager.parseVersion(currentCode)
        val sourceLabel = if (ScriptManager.hasCustomScript(this)) "Özel (Güncellenmiş)" else "Varsayılan (Paket İçi)"
        tvStatus.text = "Kaynak: $sourceLabel\nSürüm: $version\nBoyut: ${currentCode.length} karakter"

        switchEnabled.isChecked = ScriptManager.isEnabled(this)
        switchEnabled.setOnCheckedChangeListener { _, isChecked ->
            ScriptManager.setEnabled(this, isChecked)
        }

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.script_dialog_title)
            .setView(view)
            .setNegativeButton(R.string.close, null)
            .create()

        btnLoadFile.setOnClickListener {
            dialog.dismiss()
            openScriptLauncher.launch(arrayOf("text/*", "application/javascript", "*/*"))
        }

        btnUpdateUrl.setOnClickListener {
            dialog.dismiss()
            showUrlUpdateDialog()
        }

        btnEditCode.setOnClickListener {
            dialog.dismiss()
            showInlineCodeEditorDialog(currentCode)
        }

        btnReset.setOnClickListener {
            ScriptManager.resetToDefault(this)
            Toast.makeText(this, "Varsayılan betiğe sıfırlandı.", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
            lastInjectedUrl = null
            binding.webView.reload()
        }

        dialog.show()
    }

    private fun importScriptFromUri(uri: Uri) {
        try {
            val content = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use {
                it.readText()
            } ?: ""
            if (content.isBlank()) {
                Toast.makeText(this, "Seçilen dosya boş.", Toast.LENGTH_SHORT).show()
                return
            }
            ScriptManager.saveCustomScript(this, content)
            Toast.makeText(
                this,
                "Betik güncellendi (v${ScriptManager.parseVersion(content)}).",
                Toast.LENGTH_SHORT
            ).show()
            lastInjectedUrl = null
            binding.webView.reload()
        } catch (e: Exception) {
            Toast.makeText(this, "Dosya okunamadı: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showUrlUpdateDialog() {
        val input = EditText(this).apply {
            hint = "https://raw.githubusercontent.com/.../script.user.js"
            setText(ScriptManager.getRemoteUrl(this@MainActivity))
            setSingleLine(true)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("URL'den Betik Güncelle")
            .setView(input)
            .setPositiveButton("İndir ve Kaydet") { _, _ ->
                val urlStr = input.text.toString().trim()
                if (urlStr.startsWith("https://") || urlStr.startsWith("http://")) {
                    ScriptManager.setRemoteUrl(this, urlStr)
                    downloadScriptFromUrl(urlStr)
                } else {
                    Toast.makeText(this, "Geçerli bir URL girin.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun downloadScriptFromUrl(urlStr: String) {
        Toast.makeText(this, "Betik indiriliyor...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 10000
                    readTimeout = 15000
                    requestMethod = "GET"
                }
                val code = conn.responseCode
                if (code !in 200..299) {
                    runOnUiThread {
                        Toast.makeText(this, "İndirme hatası: HTTP $code", Toast.LENGTH_LONG).show()
                    }
                    return@Thread
                }
                val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                conn.disconnect()
                if (body.isBlank()) {
                    runOnUiThread {
                        Toast.makeText(this, "İndirilen dosya boş.", Toast.LENGTH_SHORT).show()
                    }
                    return@Thread
                }
                ScriptManager.saveCustomScript(this, body)
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "Betik güncellendi (v${ScriptManager.parseVersion(body)}).",
                        Toast.LENGTH_SHORT
                    ).show()
                    lastInjectedUrl = null
                    binding.webView.reload()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "İndirme başarısız: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun showInlineCodeEditorDialog(currentCode: String) {
        val editor = EditText(this).apply {
            setText(currentCode)
            minLines = 10
            maxLines = 18
            textSize = 12f
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Betik Kodunu Düzenle")
            .setView(editor)
            .setPositiveButton("Kaydet ve Yenile") { _, _ ->
                val updated = editor.text.toString()
                if (updated.isNotBlank()) {
                    ScriptManager.saveCustomScript(this, updated)
                    Toast.makeText(this, "Betik kaydedildi.", Toast.LENGTH_SHORT).show()
                    lastInjectedUrl = null
                    binding.webView.reload()
                }
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    override fun onPause() {
        super.onPause()
        binding.webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        binding.webView.onResume()
    }

    override fun onDestroy() {
        binding.webView.destroy()
        super.onDestroy()
    }
}
