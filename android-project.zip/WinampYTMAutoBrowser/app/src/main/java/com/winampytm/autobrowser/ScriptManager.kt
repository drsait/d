package com.winampytm.autobrowser

import android.content.Context
import java.io.File

object ScriptManager {
    private const val PREFS_NAME = "winamp_ytm_prefs"
    private const val KEY_ENABLED = "script_enabled"
    private const val KEY_DESKTOP_MODE = "desktop_mode"
    private const val KEY_REMOTE_URL = "remote_script_url"
    private const val CUSTOM_SCRIPT_FILE = "custom_winamp_ytm.user.js"
    private const val ASSET_SCRIPT_FILE = "winamp_ytm.user.js"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_ENABLED, true)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun isDesktopMode(context: Context): Boolean =
        prefs(context).getBoolean(KEY_DESKTOP_MODE, true)

    fun setDesktopMode(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_DESKTOP_MODE, enabled).apply()
    }

    fun getRemoteUrl(context: Context): String =
        prefs(context).getString(KEY_REMOTE_URL, "") ?: ""

    fun setRemoteUrl(context: Context, url: String) {
        prefs(context).edit().putString(KEY_REMOTE_URL, url).apply()
    }

    fun hasCustomScript(context: Context): Boolean {
        val file = File(context.filesDir, CUSTOM_SCRIPT_FILE)
        return file.exists() && file.length() > 0
    }

    fun getActiveScript(context: Context): String {
        val customFile = File(context.filesDir, CUSTOM_SCRIPT_FILE)
        if (customFile.exists() && customFile.length() > 0) {
            return customFile.readText(Charsets.UTF_8)
        }
        return context.assets.open(ASSET_SCRIPT_FILE).bufferedReader(Charsets.UTF_8).use {
            it.readText()
        }
    }

    fun saveCustomScript(context: Context, scriptContent: String) {
        val customFile = File(context.filesDir, CUSTOM_SCRIPT_FILE)
        customFile.writeText(scriptContent, Charsets.UTF_8)
    }

    fun resetToDefault(context: Context) {
        val customFile = File(context.filesDir, CUSTOM_SCRIPT_FILE)
        if (customFile.exists()) {
            customFile.delete()
        }
    }

    fun parseVersion(scriptContent: String): String {
        val regex = Regex("@version\s+([^\r\n]+)")
        val match = regex.find(scriptContent)
        return match?.groupValues?.getOrNull(1)?.trim() ?: "Bilinmiyor"
    }

    fun wrapForInjection(rawScript: String): String {
        return """
            (function() {
                if (window.__winampYtmInjected) return;
                window.__winampYtmInjected = true;
                try {
                    $rawScript
                } catch (err) {
                    console.error('[WinampYTMAutoBrowser] Script error:', err);
                }
            })();
        """.trimIndent()
    }
}
