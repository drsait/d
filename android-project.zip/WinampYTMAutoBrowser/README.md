# Winamp YTM Auto Browser

`https://music.youtube.com` adresini ana sayfa olarak açan, üzerine **Winamp - YouTube Music** userscript kodunu otomatik enjekte eden ve betiği uygulama içinden güncelleyebileceğiniz Android Studio (Kotlin) projesi.

## Özellikler
- **Ana Sayfa:** `https://music.youtube.com` otomatik açılır.
- **Masaüstü Modu (PC):** Varsayılan olarak açıktır; böylece masaüstü YouTube Music arayüzü ve Winamp betiğinin beklediği DOM/WebGL2/Web Audio bileşenleri uyumlu çalışır.
- **Canlı Betik Güncelleme ("Betik" Düğmesi):**
  - **Dosyadan Yükle (.js / .txt):** Telefonunuzdaki güncel betik dosyasını seçip anında uygulayabilirsiniz.
  - **URL'den Güncelle:** GitHub Raw / Gist gibi bir bağlantıdan yeni sürümü indirebilirsiniz.
  - **Kodu Düzenle / Yapıştır:** Uygulama içinden kodu doğrudan düzenleyebilirsiniz.
  - **Varsayılana Sıfırla:** Paket içi varsayılan betiğe döner.
- **Android Auto / Araç Desteği:** Manifest dosyasında `CAR_LAUNCHER` (Android 15+ park halindeki uygulamalar) ve `APP_BROWSER` (Android Automotive OS tarayıcı kategorisi) bildirimleri yer alır.

## Kurulum ve Derleme (Android Studio)
1. Bu klasörü Android Studio ile açın (**Open** -> `WinampYTMAutoBrowser`).
2. Kendi `Winamp - YouTube Music-2.95.37 (1).txt` dosyanızın içeriğini `app/src/main/assets/winamp_ytm.user.js` dosyasının içine yapıştırın (veya APK'yı kurduktan sonra uygulama içindeki **Betik -> Dosyadan Yükle** menüsünden seçin).
3. Gradle senkronizasyonunun tamamlanmasını bekleyin ve **Build > Build APK(s)** ile APK oluşturun.

## Android Auto Notu
- Google Play politikası gereği Android Auto'da park halindeki uygulamalar için resmi olarak yalnızca **Oyunlar (Games)** kategorisi yayınlanabilmektedir; **Tarayıcılar (Browsers)** kategorisi ise resmi olarak **Android Automotive OS** (Google built-in) araçlarda desteklenmektedir.
- Kişisel kullanım ve test için Android Auto Geliştirici Ayarları'ndan **Bilinmeyen kaynaklar** seçeneğini etkinleştirerek veya Desktop Head Unit (DHU) ile test edebilirsiniz.
