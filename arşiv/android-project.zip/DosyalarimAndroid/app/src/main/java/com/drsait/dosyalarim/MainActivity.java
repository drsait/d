package com.drsait.dosyalarim;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.*;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final String DEFAULT_URL="https://drsait.github.io/d/";
    private static final int FILE_REQUEST=91;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private LinearLayout root;
    private boolean showingWeb=false;
    private String currentUrl;
    private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
    private void fullscreen(){getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);}
    @Override public void onCreate(Bundle b){super.onCreate(b);fullscreen();
        Uri uri=getIntent().getData();
        if(uri!=null && "site".equals(uri.getScheme()) && "open".equals(uri.getHost())){
            String target=uri.getQueryParameter("url");
            if(valid(target)){openSite(target);return;}
        }
        showHome();
    }
    private boolean valid(String u){if(u==null)return false;try{Uri p=Uri.parse(u);return "https".equalsIgnoreCase(p.getScheme())&&p.getHost()!=null&&!p.getHost().isEmpty();}catch(Exception e){return false;}}
    private JSONArray entries(){try{return new JSONArray(getPreferences(0).getString("sites","[]"));}catch(Exception e){return new JSONArray();}}
    private void save(JSONArray a){getPreferences(0).edit().putString("sites",a.toString()).apply();}
    private TextView label(String text,int size){TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setTextColor(Color.rgb(30,41,59));t.setPadding(dp(8),dp(8),dp(8),dp(8));return t;}
    private void showHome(){showingWeb=false;if(web!=null){web.destroy();web=null;}
        getWindow().getDecorView().setSystemUiVisibility(0);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(0xfff5f7fb);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(25),dp(18),dp(22));sc.addView(root);setContentView(sc);
        TextView heading=label("Sitelerim",27);heading.setTypeface(null,1);root.addView(heading);
        root.addView(label("Site ekle, ardından Android ana ekranına kısayol oluştur.",14));
        EditText title=new EditText(this);title.setSingleLine(true);title.setHint("Kısayol adı (ör. Hastane)");root.addView(title);
        EditText address=new EditText(this);address.setSingleLine(true);address.setInputType(17);address.setHint("https://ornek.com");root.addView(address);
        Button add=new Button(this);add.setText("SİTE EKLE VE ANA EKRANA KISAYOL OLUŞTUR");root.addView(add);
        add.setOnClickListener(v->{String name=title.getText().toString().trim(),url=address.getText().toString().trim();
            if(!url.contains("://"))url="https://"+url;
            if(name.isEmpty()||!valid(url)){Toast.makeText(this,"Geçerli isim ve HTTPS adresi girin",Toast.LENGTH_LONG).show();return;}
            JSONArray a=entries();JSONObject o=new JSONObject();try{o.put("name",name);o.put("url",url);a.put(o);save(a);}catch(Exception ignored){}
            pinShortcut(name,url);showHome();});
        TextView sub=label("Kayıtlı siteler",19);sub.setTypeface(null,1);root.addView(sub);
        JSONArray sites=entries();if(sites.length()==0){root.addView(label("Henüz site eklenmedi.",14));}
        for(int i=0;i<sites.length();i++){JSONObject o=sites.optJSONObject(i);if(o==null)continue;
            String name=o.optString("name"),url=o.optString("url");final int idx=i;
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(9),dp(10),dp(12));card.setBackgroundColor(Color.WHITE);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(7),0,dp(7));root.addView(card,lp);
            TextView nm=label(name,18);nm.setTypeface(null,1);card.addView(nm);TextView addr=label(url,12);card.addView(addr);
            LinearLayout actions=new LinearLayout(this);card.addView(actions);
            Button open=new Button(this);open.setText("Aç");actions.addView(open,new LinearLayout.LayoutParams(0,-2,1));open.setOnClickListener(v->openSite(url));
            Button pin=new Button(this);pin.setText("Kısayol");actions.addView(pin,new LinearLayout.LayoutParams(0,-2,1));pin.setOnClickListener(v->pinShortcut(name,url));
            Button del=new Button(this);del.setText("Sil");actions.addView(del,new LinearLayout.LayoutParams(0,-2,1));del.setOnClickListener(v->{new AlertDialog.Builder(this).setMessage("Bu siteyi listeden sil?").setNegativeButton("Vazgeç",null).setPositiveButton("Sil",(d,w)->{JSONArray newer=new JSONArray();JSONArray old=entries();for(int j=0;j<old.length();j++)if(j!=idx)newer.put(old.opt(j));save(newer);showHome();}).show();});
        }
        root.addView(label("Not: Kısayolları ana ekrandan kaldırmak için kısayola uzun basın. Listeyi silmek, ana ekrandaki kısayolu otomatik silmez.",12));
    }
    private void pinShortcut(String name,String url){
        if(Build.VERSION.SDK_INT<26){Toast.makeText(this,"Kısayol ekleme Android 8+ gerektirir",Toast.LENGTH_LONG).show();return;}
        ShortcutManager mgr=getSystemService(ShortcutManager.class);
        if(mgr==null||!mgr.isRequestPinShortcutSupported()){Toast.makeText(this,"Ana ekran başlatıcınız kısayol eklemeyi desteklemiyor",Toast.LENGTH_LONG).show();return;}
        Intent target=new Intent(this,MainActivity.class);target.setAction(Intent.ACTION_VIEW);target.setData(new Uri.Builder().scheme("site").authority("open").appendQueryParameter("url",url).build());target.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        Bitmap bmp=Bitmap.createBitmap(dp(96),dp(96),Bitmap.Config.ARGB_8888);Canvas c=new Canvas(bmp);Paint p=new Paint(3);p.setColor(0xff2563eb);c.drawRoundRect(0,0,bmp.getWidth(),bmp.getHeight(),dp(22),dp(22),p);
        p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(dp(46));c.drawText(name.substring(0,1).toUpperCase(Locale.getDefault()),bmp.getWidth()/2f,dp(65),p);
        String id="site_"+UUID.randomUUID().toString();
        ShortcutInfo shortcut=new ShortcutInfo.Builder(this,id).setShortLabel(name.length()>30?name.substring(0,30):name).setLongLabel(name).setIcon(Icon.createWithBitmap(bmp)).setIntent(target).build();
        try{mgr.requestPinShortcut(shortcut,null);Toast.makeText(this,"Ana ekran kısayol onayını kontrol edin",Toast.LENGTH_LONG).show();}
        catch(Exception e){Toast.makeText(this,"Kısayol eklenemedi: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void openSite(String url){if(!valid(url)){showHome();return;}currentUrl=url;showingWeb=true;fullscreen();
        web=new WebView(this);setContentView(web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(true);s.setJavaScriptCanOpenWindowsAutomatically(false);
        CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){Uri u=r.getUrl();String scheme=u.getScheme();if("http".equalsIgnoreCase(scheme)||"https".equalsIgnoreCase(scheme))return false;try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}return true;}});
        web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> callback,FileChooserParams params){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;try{startActivityForResult(params.createIntent(),FILE_REQUEST);return true;}catch(Exception e){fileCallback=null;return false;}}});
        web.setDownloadListener((u,agent,disp,mime,len)->{try{DownloadManager.Request req=new DownloadManager.Request(Uri.parse(u));req.setMimeType(mime);String cookies=CookieManager.getInstance().getCookie(u);if(cookies!=null)req.addRequestHeader("Cookie",cookies);req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,URLUtil.guessFileName(u,disp,mime));((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);Toast.makeText(this,"İndirme başlatıldı",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"İndirme başlatılamadı",Toast.LENGTH_LONG).show();}});
        web.loadUrl(url);
    }
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==FILE_REQUEST&&fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res,data));fileCallback=null;}}
    @Override public void onBackPressed(){if(showingWeb){if(web!=null&&web.canGoBack())web.goBack();else showHome();}else super.onBackPressed();}
    @Override public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(focus&&showingWeb)fullscreen();}
    @Override protected void onDestroy(){if(web!=null)web.destroy();super.onDestroy();}
}
